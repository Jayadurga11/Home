//
//  DataModel.swift
//  Home
//
//  Created by Rahul on 18/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import Foundation
import UIKit
    
struct FRIENDSModel {
    let title:String?
    let img:String?
    let description:String?
 
    
    
}
struct GROUPSModel {
    let title:String?
    let img:String?
    let description:String?
 
    
}
struct ACTIVITYModel {
    let title:String?
    let img:String?
    let description:String?
    
    
    

}
