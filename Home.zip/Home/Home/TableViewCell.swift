//
//  TableViewCell.swift
//  Home
//
//  Created by Rahul on 18/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var sImage1: UIImageView!
    
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var descrpitionLbl: UILabel!
    
    
    @IBOutlet weak var priceLbl: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func plusBtn(_ sender: Any) {
        
       
        
    }
    
}
