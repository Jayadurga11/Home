//
//  ViewController.swift
//  Home
//
//  Created by Rahul on 18/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var splitwiseLbl: UILabel!
    
    @IBOutlet weak var view1: UIView!
    
    @IBOutlet weak var mImage: UIImageView!
    
    @IBOutlet weak var mehaLbl: UILabel!
    
    @IBOutlet weak var youOwed: UILabel!
    
    @IBOutlet weak var price1: UILabel!
    
    @IBOutlet weak var youOwe: UILabel!
    
    @IBOutlet weak var price2: UILabel!
    
    @IBOutlet weak var totalBalance: UILabel!
    
    @IBOutlet weak var price3: UILabel!
    
    
    @IBOutlet weak var segment2: UISegmentedControl!
    
    @IBOutlet weak var tableview: UITableView!
    
    var FriendsData:[FRIENDSModel] = []
    var GroupsData:[GROUPSModel] = []
    var ActivityData:[ACTIVITYModel] = []

    override func viewDidLoad() {
        super.viewDidLoad()
      
        FriendsData = [
           FRIENDSModel(title: "Subodh Kolhe", img:"friends1", description: "You owe"),
           FRIENDSModel(title: "Shobhit Bakliwal", img:"friends2 ", description: "owes you"),
           FRIENDSModel(title: "Firasat Durrani", img:"friends3", description: "owes you"),
           FRIENDSModel(title: "Sushil Kumar", img:"friends1 ", description: "you owe")
                  ]
              
              
          GroupsData = [
           GROUPSModel(title: "Trip To Lonavala", img:"groups1", description: "You owe Shubham"),
          GROUPSModel(title: "Movie Night", img:"groups2", description: "Shobhit Bakliwal owes you"),
         GROUPSModel(title: "Dinner at Canto", img:"groups3", description: "Firasat Durrani owes you"),
         GROUPSModel(title: "Trip To Matheran", img:"groups1", description: "You owe Sushil Kumar")
              ]

        ActivityData = [

          ACTIVITYModel(title: "You Added Fries", img:"activity1", description: "Shobhit B. owes you"),
          ACTIVITYModel(title: "Shobhit B. added to the group", img:"activity2", description: "Movie Night"),
          ACTIVITYModel(title: "You added Shubham to the group", img:"groups1", description: "Trip to Lonavala"),
          ACTIVITYModel(title: "You settled up with Sushil Kumar", img:"friends2", description: "You paid ₹500"),
         ]
    
    }


    @IBAction func menubarBtn(_ sender: Any) {
        
          
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
              let viewController2 = storyBoard.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
          self.present(viewController2,animated: true,completion: nil)
        
        
        
        
    }
    
    
    @IBAction func searchbarBtn(_ sender: Any) {
    }
    
    
    @IBAction func menuBtn(_ sender: Any) {
    }
    
    @IBAction func segment1(_ sender: Any) {
    }
    
}

extension ViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell",for: indexPath) as! TableViewCell
        switch segment2.selectedSegmentIndex{
        case 0:
            cell.sImage1.image = UIImage(named: FriendsData[indexPath.row].img!)
            cell.titleLbl.text = FriendsData[indexPath.row].title
            cell.descrpitionLbl.text = FriendsData[indexPath.row].description
            
            break
            
        default:
            break
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var value = 0
        switch  segment2.selectedSegmentIndex{
        case 0:
            value = FriendsData.count
            break
        case 1:
            value = GroupsData.count
            break
        case 2:
            value = ActivityData.count
            break
        default:
            break
        }
        return value
    }

        }

    
    


