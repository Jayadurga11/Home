//
//  ViewController2.swift
//  Home
//
//  Created by Rahul on 18/05/23.
//  Copyright © 2023 Rahul. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
    
    
    @IBOutlet weak var addexpenseLbl: UILabel!
    
    
    @IBOutlet weak var withyouLbl: UILabel!
    
    
    @IBOutlet weak var textfield1: UITextField!
    
    
    @IBOutlet weak var nameofexpenseLbl: UILabel!
    
    @IBOutlet weak var todayLbl: UILabel!
    
    
    @IBOutlet weak var expenseImage: UIImageView!
    
    @IBOutlet weak var priceLbl: UILabel!
    
    
    
    @IBOutlet weak var textfield2: UITextField!
    
    
    @IBOutlet weak var equalsplitLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }
    

    @IBAction func doneBtn(_ sender: Any) {
    }
    
}
